#pragma once

DECLARE_LOG_CATEGORY_EXTERN(LogObserverSnippets, Log, All);