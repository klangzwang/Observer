#pragma once
#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "ValeaToolsLibrary.generated.h"

USTRUCT(BlueprintType)
struct FSnippetData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "ValeaTools")
	FString Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "ValeaTools")
	FString Content; // Der serialisierte Blueprint-Text
};

UCLASS()
class VALEATOOLS_API UValeaToolsLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/** Speichert einen String als Snippet-Datei im Plugin-Ordner */
	static bool SaveSnippet(const FString& SnippetName, const FString& Payload);

	/** Lädt alle Snippets aus dem Verzeichnis */
	static TArray<FSnippetData> GetAllSnippets();

	/** Hilfsfunktion: Ermittelt den Pfad zum Snippet-Ordner */
	static FString GetSnippetsPath();
};