#include "ValeaToolsSnippets.h"
#include "BlueprintEditorModule.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "ValeaTools"

const FName FValeaToolsSnippets::SnippetsTabId = FName("ValeaToolsSnippets");

void FValeaToolsSnippets::RegisterBlueprintEditorExtension()
{
	// 1. Globalen Tab Spawner registrieren (funktioniert zuverlässiger für Nomad Tabs)
	FTabSpawnerEntry& Spawner = FGlobalTabmanager::Get()->RegisterNomadTabSpawner(
		SnippetsTabId,
		FOnSpawnTab::CreateStatic(&FValeaToolsSnippets::SpawnSnippetsTab)
	)
		.SetDisplayName(LOCTEXT("SnippetsTabTitle", "Snippets"))
		.SetMenuType(ETabSpawnerMenuType::Hidden); // Wir blenden es aus dem Standard-Menü aus...

	// 2. ...und fügen es händisch NUR in den Blueprint-Editor ein
	FBlueprintEditorModule& BlueprintEditorModule = FModuleManager::LoadModuleChecked<FBlueprintEditorModule>("Kismet");
	TSharedPtr<FExtender> MenuExtender = MakeShareable(new FExtender());

	MenuExtender->AddMenuExtension(
		"WindowLayout",
		EExtensionHook::After,
		nullptr,
		FMenuExtensionDelegate::CreateStatic(&FValeaToolsSnippets::OnExtendBlueprintEditorMenu)
	);

	BlueprintEditorModule.GetMenuExtensibilityManager()->AddExtender(MenuExtender);
}

void FValeaToolsSnippets::UnregisterBlueprintEditorExtension()
{
	// Unbedingt den globalen Spawner wieder freigeben
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(SnippetsTabId);
}

TSharedRef<SDockTab> FValeaToolsSnippets::SpawnSnippetsTab(const FSpawnTabArgs& TabArgs)
{
	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			SNew(SBox)
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("SnippetPlaceholder", "Hier entstehen deine Observer-Snippets!"))
			]
		];
}

void FValeaToolsSnippets::OnExtendBlueprintEditorMenu(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.BeginSection("ValeaTools", LOCTEXT("ValeaToolsHeader", "ValeaTools"));
	{
		MenuBuilder.AddMenuEntry(
			LOCTEXT("SnippetsTitle", "Snippets"),
			LOCTEXT("SnippetsTooltip", "Open the Snippet Tap Window"),
			FSlateIcon(FValeaToolsStyle::GetStyleSetName(), "ValeaTools.SnippetsIcon"),
			FUIAction(FExecuteAction::CreateStatic(&FValeaToolsSnippets::ExecuteSnippetWindow))
		);
	}
	MenuBuilder.EndSection();
}

void FValeaToolsSnippets::ExecuteSnippetWindow()
{
	FBlueprintEditorModule& BlueprintEditorModule = FModuleManager::LoadModuleChecked<FBlueprintEditorModule>("Kismet");
	// Das Fenster im aktuellen Kontext herbeirufen
	FGlobalTabmanager::Get()->TryInvokeTab(SnippetsTabId);
}

#undef LOCTEXT_NAMESPACE