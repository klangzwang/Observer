#include "ValeaToolsLibrary.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/PlatformFileManager.h"
#include "Interfaces/IPluginManager.h"

FString UValeaToolsLibrary::GetSnippetsPath()
{
	// Speichert die Snippets im Plugin-Verzeichnis unter /Saved/Snippets/
	FString BaseDir = IPluginManager::Get().FindPlugin(TEXT("ValeaTools"))->GetBaseDir();
	return FPaths::Combine(*BaseDir, TEXT("Saved"), TEXT("Snippets"));
}

bool UValeaToolsLibrary::SaveSnippet(const FString& SnippetName, const FString& Payload)
{
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	FString Directory = GetSnippetsPath();

	if (!PlatformFile.DirectoryExists(*Directory))
	{
		PlatformFile.CreateDirectoryTree(*Directory);
	}

	FString FullPath = FPaths::Combine(*Directory, FString::Printf(TEXT("%s.txt"), *SnippetName));
	return FFileHelper::SaveStringToFile(Payload, *FullPath);
}

TArray<FSnippetData> UValeaToolsLibrary::GetAllSnippets()
{
	TArray<FSnippetData> FoundSnippets;
	FString Directory = GetSnippetsPath();
	
	TArray<FString> FileNames;
	IFileManager::Get().FindFiles(FileNames, *Directory, TEXT("txt"));

	for (const FString& FileName : FileNames)
	{
		FString FullPath = FPaths::Combine(*Directory, *FileName);
		FString FileContent;
		if (FFileHelper::LoadFileToString(FileContent, *FullPath))
		{
			FSnippetData Data;
			Data.Name = FPaths::GetBaseFilename(FileName);
			Data.Content = FileContent;
			FoundSnippets.Add(Data);
		}
	}
	return FoundSnippets;
}