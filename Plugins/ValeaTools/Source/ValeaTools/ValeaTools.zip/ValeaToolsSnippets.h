#pragma once

#include "CoreMinimal.h"
#include "Widgets/Docking/SDockTab.h"

class FMenuBuilder;

class VALEATOOLS_API FValeaToolsSnippets
{
public:
	static void RegisterBlueprintEditorExtension();
	static void UnregisterBlueprintEditorExtension();

	// Die eindeutige ID für dein Snippet-Fenster
	static const FName SnippetsTabId;

private:
	static void OnExtendBlueprintEditorMenu(FMenuBuilder& MenuBuilder);
	static void ExecuteSnippetWindow();
	
	// Erzeugt den eigentlichen Tab-Inhalt
	static TSharedRef<SDockTab> SpawnSnippetsTab(const FSpawnTabArgs& TabArgs);
};