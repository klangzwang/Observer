#include "ValeaToolsStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Interfaces/IPluginManager.h"
#include "Slate/SlateGameResources.h"

TSharedPtr<FSlateStyleSet> FValeaToolsStyle::StyleInstance = nullptr;

void FValeaToolsStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = MakeShareable(new FSlateStyleSet("ValeaToolsStyle"));

		// Pfad zum Resources-Ordner deines Plugins bestimmen
		FString ContentDir = IPluginManager::Get().FindPlugin("ValeaTools")->GetBaseDir() / TEXT("Resources");
		StyleInstance->SetContentRoot(ContentDir);

		// Das Icon registrieren (Bildname ohne Endung)
		StyleInstance->Set("ValeaTools.SnippetsIcon", new FSlateImageBrush(StyleInstance->RootToContentDir(TEXT("Icon_Snippets_16x"), TEXT(".png")), FVector2D(16.0f, 16.0f)));

		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FValeaToolsStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

TSharedPtr<ISlateStyle> FValeaToolsStyle::Get() { return StyleInstance; }
FName FValeaToolsStyle::GetStyleSetName() { return StyleInstance->GetStyleSetName(); }