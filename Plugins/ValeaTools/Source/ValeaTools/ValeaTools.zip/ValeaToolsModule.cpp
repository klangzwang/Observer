#include "Modules/ModuleManager.h"
#include "ValeaToolsSnippets.h"
#include "BlueprintEditorModule.h"

#define LOCTEXT_NAMESPACE "FValeaToolsModule"

class FValeaToolsModule : public IModuleInterface
{
	
public:

	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};

void FValeaToolsModule::StartupModule()
{
	FModuleManager::Get().LoadModuleChecked<FBlueprintEditorModule>("Kismet");
	
	FValeaToolsStyle::Initialize();
	FValeaToolsSnippets::RegisterBlueprintEditorExtension();
}

void FValeaToolsModule::ShutdownModule()
{
	FValeaToolsStyle::Shutdown();
	FValeaToolsSnippets::UnregisterBlueprintEditorExtension();
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FValeaToolsModule, ValeaTools)