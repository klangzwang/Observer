#include "OBUILoadingSettings.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(OBUILoadingSettings)

UOBUILoadingSettings::UOBUILoadingSettings()
{
	CategoryName = TEXT("Game");
}
