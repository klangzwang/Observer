#pragma once
#include "Engine/DataAsset.h"
#include "OBLobbyBackground.generated.h"

class UObject;
class UWorld;

UCLASS(config=EditorPerProjectUserSettings, MinimalAPI)
class UOBLobbyBackground : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TSoftObjectPtr<UWorld> BackgroundLevel;
};
