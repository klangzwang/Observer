#pragma once
#include "Engine/AssetManager.h"
#include "Engine/DataAsset.h"
#include "Engine/StreamableManager.h"
#include "OBAssetManager.generated.h"

DECLARE_DELEGATE_OneParam(FOBAssetManagerStartupJobSubstepProgress, float /*NewProgress*/);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOBAssetManagerOnInitialLoadProgress, float, NewPercent);

struct FOBAssetManagerStartupJob
{
	FOBAssetManagerStartupJobSubstepProgress SubstepProgressDelegate;
	TFunction<void(const FOBAssetManagerStartupJob&, TSharedPtr<FStreamableHandle>&)> JobFunc;
	FString JobName;
	float JobWeight;
	mutable double LastUpdate = 0;

	/** Simple job that is all synchronous */
	FOBAssetManagerStartupJob(const FString& InJobName, const TFunction<void(const FOBAssetManagerStartupJob&, TSharedPtr<FStreamableHandle>&)>& InJobFunc, float InJobWeight)
		: JobFunc(InJobFunc)
		, JobName(InJobName)
		, JobWeight(InJobWeight)
	{
	}

	/** Perform actual loading, will return a handle if it created one */
	TSharedPtr<FStreamableHandle> DoJob() const;

	void UpdateSubstepProgress(float NewProgress) const
	{
		SubstepProgressDelegate.ExecuteIfBound(NewProgress);
	}

	void UpdateSubstepProgressFromStreamable(TSharedRef<FStreamableHandle> StreamableHandle) const
	{
		if (SubstepProgressDelegate.IsBound())
		{
			// StreamableHandle::GetProgress traverses() a large graph and is quite expensive
			double Now = FPlatformTime::Seconds();
			if (LastUpdate - Now > 1.0 / 60)
			{
				SubstepProgressDelegate.Execute(StreamableHandle->GetProgress());
				LastUpdate = Now;
			}
		}
	}
};

UCLASS(Config = Game)
class OBSERVERFRAMEWORK_API UOBAssetManager : public UAssetManager
{
	GENERATED_BODY()

public:

	UOBAssetManager();

	static UOBAssetManager& Get();

protected:

	static UObject* SynchronousLoadAsset(const FSoftObjectPath& AssetPath);

	void AddLoadedAsset(const UObject* Asset);

	virtual void StartInitialLoading() override;

	void PreloadEssentialAssets();

#if WITH_EDITOR
	virtual void PreBeginPIE(bool bStartSimulate) override;
#endif

	UPrimaryDataAsset* LoadGameDataOfClass(TSubclassOf<UPrimaryDataAsset> DataClass, const TSoftObjectPtr<UPrimaryDataAsset>& DataClassPath, FPrimaryAssetType PrimaryAssetType);

//
//	Returns the asset referenced by a TSoftObjectPtr.
//  This will synchronously load the asset if it's not already loaded.
public:

	template<typename AssetType>
	static AssetType* GetAsset(const TSoftObjectPtr<AssetType>& AssetPointer, bool bKeepInMemory = true);

	template<typename AssetType>
	static TSubclassOf<AssetType> GetSubclass(const TSoftClassPtr<AssetType>& AssetPointer, bool bKeepInMemory = true);

	const UOBGameData& GetGameData();

protected:

	template <typename GameDataClass>
	const GameDataClass& GetOrLoadTypedGameData(const TSoftObjectPtr<GameDataClass>& DataPath)
	{
		if (TObjectPtr<UPrimaryDataAsset> const* pResult = GameDataMap.Find(GameDataClass::StaticClass()))
		{
			return *CastChecked<GameDataClass>(*pResult);
		}

		// Does a blocking load if needed
		return *CastChecked<const GameDataClass>(LoadGameDataOfClass(GameDataClass::StaticClass(), DataPath, GameDataClass::StaticClass()->GetFName()));
	}

protected:

	// Global game data asset to use.
	UPROPERTY(Config)
	TSoftObjectPtr<UOBGameData> OBGameDataPath;

	// Loaded version of the game data
	UPROPERTY(Transient)
	TMap<TObjectPtr<UClass>, TObjectPtr<UPrimaryDataAsset>> GameDataMap;

public:

	static void DumpLoadedAssets();

public:

	UPROPERTY(BlueprintAssignable, Category = "Observer|AssetManager")
	FOBAssetManagerOnInitialLoadProgress OnInitialLoadProgress;
	
private:

	// Flushes the StartupJobs array. Processes all startup work.
	void DoAllStartupJobs();

	void InitializeGameplayContentManager();

	// Called periodically during loads, could be used to feed the status to a loading screen
	void UpdateInitialGameContentLoadPercent(float GameContentPercent);

	// The list of tasks to execute on startup. Used to track startup progress.
	TArray<FOBAssetManagerStartupJob> StartupJobs;

private:

	UPROPERTY()
	TSet<TObjectPtr<const UObject>> LoadedAssets;

	// Used for a scope lock when modifying the list of load assets.
	FCriticalSection LoadedAssetsCritical;

protected:

	UPROPERTY(Config)
	TSoftObjectPtr<UDataTable> ItemStatsTablePath;

	void LoadItemStatsTable();
};

UCLASS(MinimalAPI, BlueprintType, Const)
class UOBGameData : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:

	UOBGameData();

	static const UOBGameData& Get();

public:

	UPROPERTY(EditDefaultsOnly)
	TArray<TSoftClassPtr<UStaticMesh>> DataArray;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Simulation")
	TArray<TSoftClassPtr<UStaticMesh>> DummyAssets;
};

//
//
//
template<typename AssetType>
AssetType* UOBAssetManager::GetAsset(const TSoftObjectPtr<AssetType>& AssetPointer, bool bKeepInMemory)
{
	AssetType* LoadedAsset = nullptr;

	const FSoftObjectPath& AssetPath = AssetPointer.ToSoftObjectPath();

	if (AssetPath.IsValid())
	{
		LoadedAsset = AssetPointer.Get();
		if (!LoadedAsset)
		{
			LoadedAsset = Cast<AssetType>(SynchronousLoadAsset(AssetPath));
			ensureAlwaysMsgf(LoadedAsset, TEXT("Failed to load asset [%s]"), *AssetPointer.ToString());
		}

		if (LoadedAsset && bKeepInMemory)
		{
			Get().AddLoadedAsset(Cast<UObject>(LoadedAsset));
		}
	}

	return LoadedAsset;
}

template<typename AssetType>
TSubclassOf<AssetType> UOBAssetManager::GetSubclass(const TSoftClassPtr<AssetType>& AssetPointer, bool bKeepInMemory)
{
	TSubclassOf<AssetType> LoadedSubclass;

	const FSoftObjectPath& AssetPath = AssetPointer.ToSoftObjectPath();

	if (AssetPath.IsValid())
	{
		LoadedSubclass = AssetPointer.Get();
		if (!LoadedSubclass)
		{
			LoadedSubclass = Cast<UClass>(SynchronousLoadAsset(AssetPath));
			ensureAlwaysMsgf(LoadedSubclass, TEXT("Failed to load asset class [%s]"), *AssetPointer.ToString());
		}

		if (LoadedSubclass && bKeepInMemory)
		{
			Get().AddLoadedAsset(Cast<UObject>(LoadedSubclass));
		}
	}

	return LoadedSubclass;
}
