#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameplayTagContainer.h"
#include "OBStealthComponent.generated.h"

UENUM(BlueprintType)
enum class EPerceptionLevel : uint8
{
    Hidden      UMETA(DisplayName = "Hidden"),
    Suspicious  UMETA(DisplayName = "Suspicious"),
    Noticed     UMETA(DisplayName = "Noticed"),
    Alert       UMETA(DisplayName = "Alert")
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class OBSERVERFRAMEWORK_API UOBStealthComponent : public UActorComponent
{
    GENERATED_BODY()

public:

    UOBStealthComponent();

    // Aktiviert den Stealth-Modus (z. B. Hocken, Tarnung)
    UFUNCTION(BlueprintCallable, Category = "Stealth")
    void EnterStealthMode();

    // Deaktiviert den Stealth-Modus
    UFUNCTION(BlueprintCallable, Category = "Stealth")
    void ExitStealthMode();

    // Gibt die aktuelle Sichtbarkeit für Gegner zurück (0.0 – 1.0)
    UFUNCTION(BlueprintPure, Category = "Stealth")
    float GetVisibilityToEnemies() const;

    // Gibt die aktuelle Geräuschentwicklung zurück (0.0 – 1.0)
    UFUNCTION(BlueprintPure, Category = "Stealth")
    float GetHearingContribution() const;

    // Gibt die aktuelle Bedrohungsstufe zurück
    UFUNCTION(BlueprintPure, Category = "Stealth")
    float GetTotalThreatLevel() const;

    // Gibt zurück, ob der Spieler in Deckung ist
    UFUNCTION(BlueprintPure, Category = "Stealth")
    bool IsInCover() const;

    // Gibt zurück, ob der Spieler im Schatten ist
    UFUNCTION(BlueprintPure, Category = "Stealth")
    bool IsInShadow() const;

    // Setzt die Basis-Sichtbarkeit (z. B. durch Ausrüstung)
    UFUNCTION(BlueprintCallable, Category = "Stealth")
    void SetBaseVisibility(float NewBase);

    // Setzt die Bewegungsgeräusch-Basis
    UFUNCTION(BlueprintCallable, Category = "Stealth")
    void SetBaseMovementNoise(float NewNoise);

protected:

    virtual void BeginPlay() override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:

    // Berechnet Lichtbelastung an Spielerposition
    float CalculateLightExposure();

    // Aktualisiert den Hörsinn basierend auf Geschwindigkeit und Untergrund
    void UpdateHearingContribution(float DeltaTime);

    // Prüft, ob Spieler im Schatten ist (basierend auf Lichtintensität)
    bool CheckInShadow();

    // Prüft, ob Spieler hinter einem Objekt steht
    bool CheckInCover();

    // Komponentenstatus
    UPROPERTY()
    bool bIsInStealth;

    // Sichtbarkeitswerte
    float BaseVisibility;
    float CurrentVisibility;
    float LightExposure; // 0 = dunkel, 1 = hell

    // Hörsystem
    float BaseMovementNoise;
    float CurrentMovementNoise;
    float HearingContribution; // 0.0 – 1.0

    // Deckung
    bool bIsCurrentlyInCover;
    bool bIsCurrentlyInShadow;

protected:

    // Parameter (EditAnywhere für Designer)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Observer|Stealth|Visibility")
    float LightPenaltyMultiplier = 0.8f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Observer|Stealth|Visibility")
    float StealthModeVisibilityMultiplier = 0.3f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Observer|Stealth|Hearing")
    float MovementNoiseSpeedFactor = 2.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Observer|Stealth|Hearing")
    TMap<FGameplayTag, float> SurfaceNoiseModifiers;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Observer|Stealth|Cover")
    float ShadowIntensityThreshold = 0.3f;

private:

    // Cache
    class APawn* OwningPawn;
};