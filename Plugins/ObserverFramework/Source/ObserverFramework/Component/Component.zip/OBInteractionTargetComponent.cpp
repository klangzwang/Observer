#include "OBInteractionTargetComponent.h"
//#include "Components/WidgetComponent.h"
#include "Components/SphereComponent.h"
#include "GameFramework/Character.h"

UOBInteractionTargetComponent::UOBInteractionTargetComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UOBInteractionTargetComponent::BeginPlay()
{
    Super::BeginPlay();

    AActor* Owner = GetOwner();
    if (!Owner)
        return;

    ConstructOverlapZones();
	//ConstructHighlighting();
    SelectMarkerComponent();

    //
    // Delegate
    //
    OnInteractionBeginDelegate.AddDynamic(this, &UOBInteractionTargetComponent::OnInteractionBegin);
    OnInteractionEndDelegate.AddDynamic(this, &UOBInteractionTargetComponent::OnInteractionEnd);

    /*
    MarkerWidgetComp = Owner->FindComponentByClass<UWidgetComponent>();
    if (MarkerWidgetComp)
    {
        MarkerWidgetComp->SetVisibility(false);
        MarkerWidgetComp->SetWidgetSpace(EWidgetSpace::Screen);
        MarkerWidgetComp->SetDrawAtDesiredSize(true);
    }
    */
}

void UOBInteractionTargetComponent::OnInteractionBegin(APawn* InInteractorPawn)
{
    OnInteractionBeginDelegate.Broadcast(InInteractorPawn);
}

void UOBInteractionTargetComponent::OnInteractionEnd(APawn* InInteractorPawn, EInteractionResult InResult)
{

}

void UOBInteractionTargetComponent::ConstructOverlapZones()
{
	TArray<USceneComponent*> AllOwnerSceneComponents;
	GetOwner()->GetComponents<USceneComponent>(AllOwnerSceneComponents);
    for(USceneComponent* SceneComp : AllOwnerSceneComponents)
    {
        if (SceneComp->GetName() == InteractionZone_ComponentToAttach)
        {
            LocComponentToAttach = SceneComp;
            break;
        }
	}

    InnerZone = NewObject<USphereComponent>(GetOwner(), TEXT("InnerZone"));
    if (InnerZone)
    {
        InnerZone->RegisterComponent();
        InnerZone->ShapeColor = FColor::Yellow;
        InnerZone->SetHiddenInGame(!bEnableDebug);

        if (LocComponentToAttach)
        {
            FAttachmentTransformRules AttachmentRules = FAttachmentTransformRules::KeepRelativeTransform;
            AttachmentRules.LocationRule = EAttachmentRule::SnapToTarget;
            AttachmentRules.RotationRule = EAttachmentRule::KeepWorld;
            AttachmentRules.ScaleRule = EAttachmentRule::KeepWorld;
            InnerZone->AttachToComponent(LocComponentToAttach, AttachmentRules);
        }
    }

    OuterZone = NewObject<USphereComponent>(GetOwner(), TEXT("OuterZone"));
    if (OuterZone)
    {
        OuterZone->RegisterComponent();
        OuterZone->ShapeColor = FColor::Green;
        OuterZone->SetHiddenInGame(!bEnableDebug);

        FAttachmentTransformRules AttachmentRules = FAttachmentTransformRules::KeepRelativeTransform;
        AttachmentRules.LocationRule = EAttachmentRule::SnapToTarget;
        AttachmentRules.RotationRule = EAttachmentRule::KeepWorld;
        AttachmentRules.ScaleRule = EAttachmentRule::KeepWorld;
        OuterZone->AttachToComponent(InnerZone, AttachmentRules);
    }

    InnerZone->OnComponentBeginOverlap.AddDynamic(this, &UOBInteractionTargetComponent::OnInnerBeginOverlap);
    InnerZone->OnComponentEndOverlap.AddDynamic(this, &UOBInteractionTargetComponent::OnInnerEndOverlap);
    OuterZone->OnComponentBeginOverlap.AddDynamic(this, &UOBInteractionTargetComponent::OnOuterBeginOverlap);
    OuterZone->OnComponentEndOverlap.AddDynamic(this, &UOBInteractionTargetComponent::OnOuterEndOverlap);

    InnerZone->SetSphereRadius(InnerZoneRadius, true);
    OuterZone->SetSphereRadius(InnerZoneRadius + FMath::Max(OuterZoneExtent, 10.f), true);
}

void UOBInteractionTargetComponent::ConstructHighlighting()
{
    TArray<USceneComponent*> LocComponents;
    USceneComponent* LocOwnerRoot;

    LocOwnerRoot = GetOwner()->GetRootComponent();
    GetOwner()->GetRootComponent()->GetChildrenComponents(true, LocComponents);
    LocComponents.Add(LocOwnerRoot);

    UPrimitiveComponent* PrimitiveComp = Cast<UPrimitiveComponent>(LocOwnerRoot);
    if (ComponentsToHighlight.Contains(PrimitiveComp->GetName()))
        HighlightedComponents.AddUnique(PrimitiveComp);

    for (USceneComponent* SceneComp : LocComponents)
    {
        PrimitiveComp = Cast<UPrimitiveComponent>(SceneComp);
        if (PrimitiveComp && ComponentsToHighlight.Contains(PrimitiveComp->GetName()))
        {
            HighlightedComponents.AddUnique(PrimitiveComp);
        }
    }
}

void UOBInteractionTargetComponent::SelectMarkerComponent()
{
    TArray<USceneComponent*> LocComponents;
    USceneComponent* LocOwnerRoot;

    LocOwnerRoot = GetOwner()->GetRootComponent();
    GetOwner()->GetRootComponent()->GetChildrenComponents(true, LocComponents);
    LocComponents.Add(LocOwnerRoot);

    for (USceneComponent* SceneComp : LocComponents)
    {
        if (SceneComp->GetName() == MarkerComponentName)
        {
            MarkerTargetComponent = SceneComp;
            break;
        }
    }

    if (!MarkerTargetComponent)
    {
        MarkerTargetComponent = LocOwnerRoot;
    }
}

void UOBInteractionTargetComponent::SetHighlight(bool bIsHighlighted)
{
    for (UPrimitiveComponent* PrimitiveComp : HighlightedComponents)
    {
        if (PrimitiveComp)
        {
            PrimitiveComp->SetRenderCustomDepth(bIsHighlighted);
        }
	}
}

void UOBInteractionTargetComponent::OnOuterBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    if (OtherActor->IsA(ACharacter::StaticClass()))
    {
        //if (MarkerWidgetComp)
        //    MarkerWidgetComp->SetVisibility(true);
    }
}

void UOBInteractionTargetComponent::OnOuterEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
    if (OtherActor->IsA(ACharacter::StaticClass()))
    {
        //if (MarkerWidgetComp)
        //   MarkerWidgetComp->SetVisibility(false);
    }
}

void UOBInteractionTargetComponent::OnInnerBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{

}

void UOBInteractionTargetComponent::OnInnerEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{

}