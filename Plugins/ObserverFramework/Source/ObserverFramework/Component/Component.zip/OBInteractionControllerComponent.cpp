#include "OBInteractionControllerComponent.h"
#include "Kismet/KismetMaterialLibrary.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(OBInteractionControllerComponent)

UOBInteractionControllerComponent::UOBInteractionControllerComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UOBInteractionControllerComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UOBInteractionControllerComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}
