#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "IOBInteractable.h"
#include "OBtypes.h"
#include "OBInteractionTargetComponent.generated.h"

class USphereComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnInteractionBegin, APawn*, InteractorPawn);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnInteractionEnd, APawn*, InteractorPawn, EInteractionResult, Result);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnInteractionUpdated, float, Alpha, int32, Repeated, APawn*, InteractorPawn);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnInteractionReactivated, APawn*, ForPawn);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnInteractionDeactivated);

UCLASS(Blueprintable, ClassGroup = Custom, meta = (BlueprintSpawnableComponent))
class UOBInteractionTargetComponent : public UActorComponent
{
    GENERATED_BODY()

public:    

    UOBInteractionTargetComponent(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

    virtual void BeginPlay() override;

protected:

    void ConstructOverlapZones();
    void ConstructHighlighting();
    void SelectMarkerComponent();

public:

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Observer|Config")
    FInteractionData InteractionConfig;

    UPROPERTY(BlueprintAssignable, Category = "Observer|Config")
    FOnInteractionBegin OnInteractionBeginDelegate;

    UPROPERTY(BlueprintAssignable, Category = "Observer|Config")
    FOnInteractionEnd OnInteractionEndDelegate;

    UPROPERTY(BlueprintAssignable, Category = "Observer|Config")
    FOnInteractionUpdated OnInteractionUpdatedDelegate;

    UPROPERTY(BlueprintAssignable, Category = "Observer|Config")
    FOnInteractionReactivated OnInteractionReactivatedDelegate;

    UPROPERTY(BlueprintAssignable, Category = "Observer|Config")
    FOnInteractionDeactivated OnInteractionDeactivatedDelegate;

protected:

    UFUNCTION(BlueprintCallable, Category = "Observer|Interaction")
    void OnInteractionBegin(APawn* InInteractorPawn);

    UFUNCTION(BlueprintCallable, Category = "Observer|Interaction")
    void OnInteractionEnd(APawn* InInteractorPawn, EInteractionResult InResult);

//
// Components
//
public:

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Observer|Interaction")
    bool bEnableDebug = false;

public:

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Observer|Interaction|MarkerSettings")
    FString MarkerComponentName;

    USceneComponent* MarkerTargetComponent;

public:

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Observer|Interaction|HighlightSettings")
    TArray<FString> ComponentsToHighlight;

    TArray<UPrimitiveComponent*> HighlightedComponents;

public:

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Observer|Interaction|InteractionSettings")
    FString InteractionZone_ComponentToAttach;

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Observer|Interaction|InteractionSettings")
    float InnerZoneRadius;

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Observer|Interaction|InteractionSettings")
    float OuterZoneExtent;

    USceneComponent* LocComponentToAttach;

//
// OuterInner SphereCollision
//
protected:

    UFUNCTION(BlueprintCallable, Category = "Observer|Interaction")
    void SetHighlight(bool bIsHighlighted);

    UPROPERTY(BlueprintReadWrite, VisibleAnywhere, Category = "Observer|Interaction")
    USphereComponent* OuterZone;

    UPROPERTY(BlueprintReadWrite, VisibleAnywhere, Category = "Observer|Interaction")
    USphereComponent* InnerZone;

    UFUNCTION()
    void OnOuterBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

    UFUNCTION()
    void OnOuterEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
 
    UFUNCTION()
    void OnInnerBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

    UFUNCTION()
	void OnInnerEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

/*
protected:

    UPROPERTY()
    class UWidgetComponent* MarkerWidgetComp;
*/
};