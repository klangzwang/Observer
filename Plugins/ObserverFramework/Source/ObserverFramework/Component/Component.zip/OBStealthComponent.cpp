#include "OBStealthComponent.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/Character.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "Components/CapsuleComponent.h"
#include "Components/LightComponent.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "GameplayTagsManager.h"

UOBStealthComponent::UOBStealthComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    PrimaryComponentTick.TickGroup = TG_PrePhysics;

    BaseVisibility = 1.0f;
    BaseMovementNoise = 0.5f;
    bIsInStealth = false;

    // Beispiel für Untergrund-Geräuschmodifikatoren
    SurfaceNoiseModifiers.Add(FGameplayTag::RequestGameplayTag("Surface.Metal"), 2.0f);
    SurfaceNoiseModifiers.Add(FGameplayTag::RequestGameplayTag("Surface.Carpet"), 0.3f);
    SurfaceNoiseModifiers.Add(FGameplayTag::RequestGameplayTag("Surface.Wood"), 1.0f);
    SurfaceNoiseModifiers.Add(FGameplayTag::RequestGameplayTag("Surface.Concrete"), 1.2f);
}

void UOBStealthComponent::BeginPlay()
{
    Super::BeginPlay();

    OwningPawn = Cast<APawn>(GetOwner());
    if (!OwningPawn)
    {
        UE_LOG(LogTemp, Warning, TEXT("OBStealthComponent: Owner is not a Pawn!"));
    }
}

void UOBStealthComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    LightExposure = CalculateLightExposure();
    bIsCurrentlyInShadow = CheckInShadow();
    bIsCurrentlyInCover = CheckInCover();

    UpdateHearingContribution(DeltaTime);
}

void UOBStealthComponent::EnterStealthMode()
{
    bIsInStealth = true;
}

void UOBStealthComponent::ExitStealthMode()
{
    bIsInStealth = false;
}

float UOBStealthComponent::GetVisibilityToEnemies() const
{
    float Visibility = BaseVisibility;

    if (bIsInStealth)
    {
        Visibility *= StealthModeVisibilityMultiplier;
    }

    // Licht erhöht Sichtbarkeit
    Visibility += LightExposure * LightPenaltyMultiplier;

    // Im Schatten? → Reduziere Sichtbarkeit
    if (bIsCurrentlyInShadow)
    {
        Visibility *= 0.4f;
    }

    // In Deckung? → fast unsichtbar
    if (bIsCurrentlyInCover)
    {
        Visibility *= 0.1f;
    }

    return FMath::Clamp(Visibility, 0.0f, 1.0f);
}

float UOBStealthComponent::GetHearingContribution() const
{
    return FMath::Clamp(HearingContribution, 0.0f, 1.0f);
}

float UOBStealthComponent::GetTotalThreatLevel() const
{
    float SightThreat = GetVisibilityToEnemies();
    float SoundThreat = GetHearingContribution();
    return FMath::Max(SightThreat, SoundThreat);
}

bool UOBStealthComponent::IsInCover() const
{
    return bIsCurrentlyInCover;
}

bool UOBStealthComponent::IsInShadow() const
{
    return bIsCurrentlyInShadow;
}

void UOBStealthComponent::SetBaseVisibility(float NewBase)
{
    BaseVisibility = FMath::Clamp(NewBase, 0.0f, 1.0f);
}

void UOBStealthComponent::SetBaseMovementNoise(float NewNoise)
{
    BaseMovementNoise = FMath::Clamp(NewNoise, 0.0f, 1.0f);
}

float UOBStealthComponent::CalculateLightExposure()
{
    FVector Location = GetOwner()->GetActorLocation() + FVector(0, 0, 50); // Kopfhöhe
    float TotalIntensity = 0.0f;
    int32 SampleCount = 6;

    for (int32 i = 0; i < SampleCount; ++i)
    {
        FRotator Rot = FRotator(0, i * (360.0f / SampleCount), 0);
        FVector Direction = Rot.Vector();
        FVector End = Location + Direction * 200.0f;

        FHitResult Hit;
        FCollisionQueryParams Params;
        Params.AddIgnoredActor(GetOwner());

        if (GetWorld()->LineTraceSingleByChannel(Hit, Location, End, ECC_Visibility, Params))
        {
            if (const ULightComponent* LightComp = Hit.GetActor()->FindComponentByClass<ULightComponent>())
            {
                float Intensity = LightComp->Intensity;
                float Distance = Hit.Distance;
                float Attenuation = FMath::Clamp(1.0f - (Distance / 400.0f), 0.0f, 1.0f);
                TotalIntensity += Intensity * Attenuation;
            }
        }
    }

    return FMath::Clamp(TotalIntensity / SampleCount, 0.0f, 1.0f);
}

void UOBStealthComponent::UpdateHearingContribution(float DeltaTime)
{
    if (!OwningPawn) return;

    float Speed = OwningPawn->GetVelocity().Size();
    float Noise = Speed * MovementNoiseSpeedFactor * BaseMovementNoise;

    // Untergrund bestimmt Geräusch
    FHitResult Hit;
    FVector Location = GetOwner()->GetActorLocation();
    FVector Down = Location - FVector(0, 0, 100);

    if (GetWorld()->LineTraceSingleByChannel(Hit, Location, Down, ECC_Visibility))
    {
        UPhysicalMaterial* PhysMat = Hit.PhysMaterial.Get();
        if (PhysMat)
        {
            FString MatName = PhysMat->GetName();
            FGameplayTag SurfaceTag = FGameplayTag::RequestGameplayTag(*FString::Printf(TEXT("Surface.%s"), *MatName));

            if (SurfaceNoiseModifiers.Contains(SurfaceTag))
            {
                Noise *= SurfaceNoiseModifiers[SurfaceTag];
            }
        }
    }

    // Glätten über Zeit
    HearingContribution = FMath::Lerp(HearingContribution, Noise, DeltaTime * 3.0f);
    HearingContribution = FMath::Clamp(HearingContribution, 0.0f, 1.0f);
}

bool UOBStealthComponent::CheckInShadow()
{
    return LightExposure < ShadowIntensityThreshold;
}

bool UOBStealthComponent::CheckInCover()
{
    FVector Start = GetOwner()->GetActorLocation() + FVector(0, 0, 90); // Schulterhöhe
    FVector End = Start - FVector(0, 0, 150); // nach unten

    FHitResult Hit;
    FCollisionQueryParams Params;
    Params.AddIgnoredActor(GetOwner());

    return GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_Camera, Params);
}