#pragma once
#include "Components/ControllerComponent.h"
#include "OBInteractionControllerComponent.generated.h"

UCLASS(meta = (BlueprintSpawnableComponent))
class UOBInteractionControllerComponent : public UControllerComponent
{
	GENERATED_BODY()

public:

	UOBInteractionControllerComponent(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
};
