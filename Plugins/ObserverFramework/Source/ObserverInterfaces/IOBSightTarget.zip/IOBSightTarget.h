#pragma once
#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "IOBSightTarget.generated.h"

struct FHitResult;

UINTERFACE(MinimalAPI, NotBlueprintable)
class UOBSightTarget : public UInterface
{
	GENERATED_BODY()
};

class IOBSightTarget
{
	GENERATED_BODY()
};
