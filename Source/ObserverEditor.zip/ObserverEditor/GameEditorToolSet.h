#pragma once

class FGameEditorToolSet
{

public:

	static void RegisterGameEditorMenus();
};
