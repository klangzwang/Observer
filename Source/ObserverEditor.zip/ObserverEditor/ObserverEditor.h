#pragma once

DECLARE_LOG_CATEGORY_EXTERN(LogObserverEditor, Log, All);